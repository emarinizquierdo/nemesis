

var rightLowerTab = new function(){
		
	function _init(){
		
		$("#rightLowerTabStripp").kendoTabStrip({
			animation:	{
				open: {
					effects: "fadeIn"
				}
			}
		
		});
		
	}
	
	this.init = _init;
	
}




